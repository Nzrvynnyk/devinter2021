# DevOps 
A compound of development (Dev) and operations (Ops), DevOps is the union of people, process, and technology to continually provide value to customers.


# Done all steps created brach.
![image](https://user-images.githubusercontent.com/80759146/111522557-16440280-8763-11eb-8a89-ec6907a5b441.png)

# Fixed Git Conflict 
![image](https://user-images.githubusercontent.com/80759146/111522794-4a1f2800-8763-11eb-8712-dc5f84a3d5a7.png)

# Last steps Push to GitHub
![image](https://user-images.githubusercontent.com/80759146/111522952-6f139b00-8763-11eb-8026-41298a10c918.png)

# Done.
