# DevOps_online_Vinnitsia_2021Q1



