# Install MSql Server created Databases DevOpstets, created 3 table Tablename, school, class,
 * First step created databases
 * Created tables with structure (id, name, ***) 
 ```
INSERT INTO `devopstest`.`school` (`id`, `name`, `Addres`) VALUES ('4', 'QA', 'Kiev') 
```
![image](https://user-images.githubusercontent.com/80759146/112720697-9ce9a400-8f08-11eb-9ada-3aad84845bb4.png)

# Select with where.
![image](https://user-images.githubusercontent.com/80759146/112720902-ba6b3d80-8f09-11eb-96ad-dd4e7f10e76d.png)
# Order by 
 The following SQL statement selects all customers from the "Tablename" table, sorted by the "age" column:
![image](https://user-images.githubusercontent.com/80759146/112720995-3a91a300-8f0a-11eb-9142-945a3a520450.png)

# Created new user with new rights Drop 
 ![image](https://user-images.githubusercontent.com/80759146/112889729-b2182b80-90de-11eb-982e-83cbaa18cc79.png)
# Created dump 
![image](https://user-images.githubusercontent.com/80759146/112893661-a3804300-90e3-11eb-834f-8bef34183692.png)

# Check accses try created, and delete tables.
![image](https://user-images.githubusercontent.com/80759146/112895933-6e292480-90e6-11eb-8daa-d78ad263ee27.png)

# Restore databases from dump 
![image](https://user-images.githubusercontent.com/80759146/112899943-733ca280-90eb-11eb-9241-a232060d438c.png)

# Transfer dabase to AWS RD server 
![image](https://user-images.githubusercontent.com/80759146/113163655-08a17900-9249-11eb-982d-2fdd0179eea2.png)

# Created DynamoBD and enter data
![image](https://user-images.githubusercontent.com/80759146/113164996-4b178580-924a-11eb-91c6-d43400181627.png)
