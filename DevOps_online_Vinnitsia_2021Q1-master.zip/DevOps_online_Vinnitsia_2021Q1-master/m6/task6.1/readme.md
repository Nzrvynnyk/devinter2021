
# task 3 ping to host
![image](https://user-images.githubusercontent.com/80759146/115785996-e5419800-a3c8-11eb-9510-a2c7efe2dc33.png)
task 4 check acces to internet 
# ![image](https://user-images.githubusercontent.com/80759146/115786096-06a28400-a3c9-11eb-98c7-35a9d5aabccf.png)
# task 5 nslookup 8.8.8.8 and epam.com
![image](https://user-images.githubusercontent.com/80759146/115786375-67ca5780-a3c9-11eb-9963-da2a9951d9e2.png)
# task 6 traceroute host
![image](https://user-images.githubusercontent.com/80759146/115786529-9f390400-a3c9-11eb-903b-1644b8bcca15.png)

![image](https://user-images.githubusercontent.com/80759146/115786725-dd362800-a3c9-11eb-911c-9d5881b28f7c.png)

