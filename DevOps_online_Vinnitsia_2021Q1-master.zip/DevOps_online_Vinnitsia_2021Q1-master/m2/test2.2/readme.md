# Created account, launched Lightsail, creted snapshot 
![image](https://user-images.githubusercontent.com/80759146/112539177-52a5dd00-8db9-11eb-98cd-0db7ab9d0ec1.png)
![image](https://user-images.githubusercontent.com/80759146/112539199-5df90880-8db9-11eb-84af-472330419709.png)
# Launch EC2 instance from snapshot
![image](https://user-images.githubusercontent.com/80759146/112673279-35cae180-8e6d-11eb-89de-17fa54d1d3fd.png)


# Created vm from snapshot
![image](https://user-images.githubusercontent.com/80759146/112539344-8ed93d80-8db9-11eb-80a7-31fbead34151.png)
# Attached disk D
![image](https://user-images.githubusercontent.com/80759146/112539622-e1b2f500-8db9-11eb-8dcf-4c473596ef03.png)
![image](https://user-images.githubusercontent.com/80759146/112540785-43c02a00-8dbb-11eb-8e8d-c00f11542ef9.png)
# Deatach add to Another Vm
![image](https://user-images.githubusercontent.com/80759146/112541525-29d31700-8dbc-11eb-9bb2-59c7ad10125a.png)
#launch WordPress and login to admin panel
![image](https://user-images.githubusercontent.com/80759146/112543063-f2fe0080-8dbd-11eb-9bf3-7bee41c33dd8.png)





# Upload file to s3 use aws cli 
![image](https://user-images.githubusercontent.com/80759146/112524698-c8ee1380-8da8-11eb-860b-6b20d3f71061.png)
# Run the online demo applications
![image](https://user-images.githubusercontent.com/80759146/112530401-10779e00-8daf-11eb-9cc9-395c01e84a13.png)

# Created Public site https://nzrvynnyk.s3.eu-central-1.amazonaws.com/nzrvynnyk/index.html
![image](https://user-images.githubusercontent.com/80759146/112538183-453c2300-8db8-11eb-91f5-4c71d4aa0894.png)



