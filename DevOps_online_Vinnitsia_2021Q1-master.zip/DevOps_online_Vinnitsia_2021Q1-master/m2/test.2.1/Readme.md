Install VirtualBox, add ubuntu, created clone ve1. 
![image](https://user-images.githubusercontent.com/80759146/111865253-9ab6a100-896e-11eb-82ce-49e8855d4962.png)

Export Ver1 
![image](https://user-images.githubusercontent.com/80759146/111865338-33e5b780-896f-11eb-99ef-7c4bd69375a4.png)


#add USB 
![image](https://user-images.githubusercontent.com/80759146/111866190-5c23e500-8974-11eb-996c-7b577b670ff2.png)

# Add shared Folder 
![image](https://user-images.githubusercontent.com/80759146/111867729-91cdcb80-897e-11eb-9724-23d55308bee4.png)

# VBoxManaga commands 
 ![image](https://user-images.githubusercontent.com/80759146/111867811-27695b00-897f-11eb-985f-93f14c0c7643.png)
![image](https://user-images.githubusercontent.com/80759146/111867872-83cc7a80-897f-11eb-854a-819a12b76242.png)

# Networks setings 
![image](https://user-images.githubusercontent.com/80759146/111868866-1ae80100-8985-11eb-9015-d5efa5dc70f7.png)

![image](https://user-images.githubusercontent.com/80759146/111868895-3f43dd80-8985-11eb-8c79-2ac483c4147c.png)
# Vagrant set up 
![image](https://user-images.githubusercontent.com/80759146/111869356-b7130780-8987-11eb-9766-69e66a145686.png)
